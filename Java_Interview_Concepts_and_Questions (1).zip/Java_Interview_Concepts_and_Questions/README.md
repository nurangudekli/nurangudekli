- [Interview Topics](#interview-topics)
    * [Lazy vs Eager](#lazy-vs-eager)
    * [LazyInitializationException](#lazyinitializationexception)
    * [@Bean vs @Component](#bean-vs-component)
    * [@Component, @Repository, @Service](#component-repository-service)
        + [Component](#component)
        + [Service](#service)
        + [Repository](#repository)
    * [@Component, @Repository, @Service summary](#component-repository-service-summary)
    * [@ComponentScan](#componentscan)
    * [IoC (Inversion of Control)](#ioc-inversion-of-control)
    * [Dependency Injection](#dependency-injection)
    * [Java Thread Pool](#java-thread-pool)
        + [Executor Thread Pool Methods](#executor-thread-pool-methods)
        + [ScheduledThreadPoolExecutor](#scheduledthreadpoolexecutor)
        + [ForkJoinPool](#forkjoinpool)
        + [Risks in using Thread Pools](#risks-in-using-thread-pools)
    * [Executors in Java](#executors-in-java)
        + [Executor](#executor)
        + [ExecutorService](#executorservice)
        + [ThreadPoolExecutor](#threadpoolexecutor)
    * [JPA Object Relational Mapping](#jpa-object-relational-mapping)
        - [ORM Framework](#orm-framework)

        + [Mapping Directions](#mapping-directions)
        + [Types of Mapping](#types-of-mapping)
    * [@EqualsAndHashCode](#equalsandhashcode)
    * [Static vs Instance](#static-vs-instance)
        + [Static Properties](#static-properties)
    * [Polymorphism, Encapsulation, Abstraction and Inheritance](#polymorphism-encapsulation-abstraction-and-inheritance)
        + [Inheritance](#inheritance)
        + [Encapsulation](#encapsulation)
        + [Polymorphism](#polymorphism)
        + [Abstraction](#abstraction)
    * [Composite](#composite)
    * [Immutable classes](#immutable-classes)
    * [Java Type System (Immutable Objects of Primitives)](#java-type-system-immutable-objects-of-primitives)
        + [Pros and Cons](#pros-and-cons)
            - [Single Item Memory Footprint](#single-item-memory-footprint)
    * [Public, Protected, default, Private](#public-protected-default-private)
    * [Thread Safety in Java](#thread-safety-in-java)
        + [How to Achieve It?](#how-to-achieve-it)
    * [SOLID](#solid)
    * [Law of Demeter (LoD)](#law-of-demeter-lod)
    * [High Cohesion / Low Coupling](#high-cohesion-/-low-coupling)
    * [ACID](#acid)
    * [What Is a Transaction?](#what-is-a-transaction)
        + [Transactions Support in Spring](#transactions-support-in-spring)
        + [Transaction Propagation in Spring](#transaction-propagation-in-spring)
            - [REQUIRED Propagation](#required-propagation)
            - [SUPPORTS Propagation](#supports-propagation)
            - [MANDATORY Propagation](#mandatory-propagation)
            - [NEVER Propagation](#never-propagation)
            - [NOT_SUPPORTED Propagation](#not_supported-propagation)
            - [REQUIRES_NEW Propagation](#requires_new-propagation)
            - [NESTED Propagation](#nested-propagation)
        + [Transaction Isolation in Spring](#transaction-isolation-in-spring)
            - [ISOLATION LEVELS](#isolation-levels)
            - [DEFAULT:](#default)
            - [READ_UNCOMMITTED Isolation](#read_uncommitted-isolation)
            - [READ_COMMITTED Isolation](#read_committed-isolation)
            - [REPEATABLE_READ Isolation](#repeatable_read-isolation)
            - [SERIALIZABLE Isolation](#serializable-isolation)
        + [Database Isolation Level](#database-isolation-level)
            - [ISOLATION LEVELS:](#isolation-levels)
    * [Composition vs Inheritance](#composition-vs-inheritance)
        - [Example of Inheritance](#example-of-inheritance)
        - [Example of Composition](#example-of-composition)
    * [NoSQL vs Relational Database](#nosql-vs-relational-database)
        + [Differences between NoSQL and Relational database](#differences-between-nosql-and-relational-database)
    * [Polling vs SSE vs Websocket](#polling-vs-sse-vs-websocket)
        + [When to use](#when-to-use)
    * [Bean Scopes](#bean-scopes)
        + [Singleton Scope](#singleton-scope)
        + [Prototype Scope](#prototype-scope)
        + [Request scope](#request-scope)
        + [Session scope](#session-scope)
        + [Application scope](#application-scope)
        + [Websocket scope](#websocket-scope)
    * [Monolithic vs Microservice](#monolithic-vs-microservice)
        + [Monolithic Pros vs Cons](#monolithic-pros-vs-cons)
        + [Microservices Pros and Cons](#microservices-pros-and-cons)
    * [REST](#rest)
        + [Why is PATCH not idempotent](#why-is-patch-not-idempotent)
        + [PUT vs PATCH](#put-vs-patch)
        + [Path params vs Query params](#path-params-vs-query-params)
    * [Spring vs Spring Boot in a nutshell](#spring-vs-spring-boot-in-a-nutshell)
    * [SQL Injection](#sql-injection)
        + [How to prevent it?](#how-to-prevent-it)
        + [What other SQL injections are there?](#what-other-sql-injections-are-there)
    * [JPA vs Hibernate](#jpa-vs-hibernate)
    * [What is JSON Web Token (JWT)?](#what-is-json-web-token-jwt)
        + [When should you use JSON Web Tokens?](#when-should-you-use-json-web-tokens)
        + [What is the JSON Web Token structure?](#what-is-the-json-web-token-structure)
            - [Header](#header)
            - [Payload](#payload)
                * [Registered claims](#registered-claims)
                * [Public claims](#public-claims)
                * [Private claims](#private-claims)
            - [Signature](#signature)
        + [How do JSON Web Tokens work?](#how-do-json-web-tokens-work)
        + [Why should we use JSON Web Tokens?](#why-should-we-use-json-web-tokens)
        + [JWT can't be modified. How?](#jwt-cant-be-modified-how)
    * [SQL Index](#sql-index)
        + [How does it work?](#how-does-it-work)
        + [Types of Indexing](#types-of-indexing)
            - [Primary Index](#primary-index)
                * [Dense Index](#dense-index)
                * [Sparse Index](#sparse-index)
            - [Secondary Index](#secondary-index)
            - [Composite Index](#composite-index)
            - [Clustering Index](#clustering-index)
                * [Clustered vs Non-Clustered Index](#clustered-vs-non-clustered-index)
                    + [Differences between Clustered Index and NonClustered Index](#differences-between-clustered-index-and-nonclustered-index)
        + [Pros and Cons of Indexing](#pros-and-cons-of-indexing)
    * [Idempotency](#idempotency)
    * [How to write Quality Code](#how-to-write-quality-code)
        + [How to measure code quality?](#how-to-measure-code-quality)
        + [How to maintain code quality?](#how-to-maintain-code-quality)
    * [Unit Testing Vs Integration Testing Vs Functional Testing](#unit-testing-vs-integration-testing-vs-functional-testing)
        + [Unit testing](#unit-testing)
        + [Integration testing](#integration-testing)
        + [Functional testing](#functional-testing)
    * [Java default methods](#java-default-methods)
        + [What happens when a class implements several interfaces that define the same _
          default_ methods.](#what-happens-when-a-class-implements-several-interfaces-that-define-the-same-_default_-methods)
    * [Java Static interface methods](#java-static-interface-methods)
    * [Test Driven Development(TDD)](#test-driven-developmenttdd)
    * [@Qualifier](#qualifier)
        + [Autowire Need for Disambiguation](#autowire-need-for-disambiguation)
            - [@Autowired vs @Inject](#autowired-vs-inject)
        + [@Qualifier annotation](#qualifier-annotation)
        + [@Qualifier vs @Primary](#qualifier-vs-primary)
        + [@Qualifier vs Autowiring by Name](#qualifier-vs-autowiring-by-name)
    * [How to write testable code](#how-to-write-testable-code)
    * [Checked Exceptions vs Unchecked Exceptions](#checked-exceptions-vs-unchecked-exceptions)

# Interview Topics

## Design Patterns

There are 4 categories when it comes to Design Patterns in OOP;

1. Creational Patterns
2. Structural Patterns
3. Behavioral Patterns
4. J2EE Patterns

### Creational Patterns

These design patterns provide a way to create objects while hiding the creation logic, rather than instantiating objects
directly using `new` operator. This gives program more flexibility in deciding which objects need to be created for a
given use case.

#### Factory Design Pattern

Factory pattern is one of the most used design pattern in Java. This type of design pattern comes under creational
pattern as this pattern provides one of the best ways to create an object.

In Factory pattern, we create object without exposing the creation logic to the client and refer to newly created object
using a common interface.

##### What is the benefit of Factory Pattern?

Factory pattern encapsulates the implementation details and underlying implementation can be changed without any impact
on caller api.

#### Abstract Factory Design Pattern

Abstract Factory Design Patterns work around a super-factory which creates other factories. This factory is also called
as factory of factories. This type of design pattern comes under creational pattern as this pattern provides one of the
best ways to create an object.

In Abstract Factory Design Pattern an interface is responsible for creating a factory of related objects without
explicitly specifying their classes. Each generated factory can give the objects as per the Factory pattern.

#### Singleton Design Pattern

Singleton Design Pattern is one of the simplest design patterns in Java. This type of design pattern comes under
creational pattern as this pattern provides one of the best ways to create an object.

This pattern involves a single class which is responsible to create an object while making sure that only single object
gets created. This class provides a way to access its only object which can be accessed directly without need to
instantiate the object of the class.

##### How can you create Singleton class in java?

It is two step process. First make the constructor private so that new operator cannot be used to instantiate the class.
Return an object of the object if not null, otherwise create the object and return the same via a method.

##### What are the differences between a static class, and a singleton class?

A static class can not be a top level class and can not implement interfaces where a singleton class can.

All members of a static class are static but for a Singleton class it is not a requirement.

A static class gets initialized when it is loaded so it can not be lazily loaded where a singleton class can be lazily
loaded.

A static class object is stored in stack whereas singleton class object is stored in heap memory space.

##### Can we create a clone of a singleton object?

Yes.

##### How to prevent cloning of a singleton object?

Throw exception within the body of `clone()` method.

#### Builder Design Pattern

Builder pattern builds a complex object using simple objects and using a step-by-step approach. This type of design
pattern comes under creational pattern as this pattern provides one of the best ways to create an object.

A Builder class builds the final object step by step. This builder is independent of other objects.

#### Prototype Design Pattern

Prototype pattern refers to creating duplicate object while keeping performance in mind. This type of design pattern
comes under creational pattern as this pattern provides one of the best ways to create an object.

This pattern involves implementing a prototype interface which tells to create a clone of the current object.

##### When Prototype pattern is to be used?

This pattern is used when creation of object directly is costly. For example, an object is to be created after a costly
database operation. We can cache the object, returns its clone on next request and update the database as and when
needed thus reducing database calls.

### Structural Patterns

These design patterns concern class and object composition. Concept of inheritance is used to compose interfaces and
define ways to compose objects to obtain new functionalities.

#### Adapter Design Pattern

Adapter pattern works as a bridge between two incompatible interfaces. This type of design pattern comes under
structural pattern as this pattern combines the capability of two independent interfaces.

This pattern involves a single class which is responsible to join functionalities of independent or incompatible
interfaces. A real life example could be a case of card reader which acts as an adapter between memory card and a
laptop. You plug in the memory card into card reader and card reader into the laptop so that memory card can be read via
laptop.

> Adapter does not add behavior in any way, it just modifies the existing interface to allow some other class to access the existing functionality.
>
> Strategy pattern on the other hand encapsulates different behavior, and allows them to be switched at run time.

### Behavioral Patterns

These design patterns are specifically concerned with communication between objects.

### J2EE Patterns

These design patterns are specifically concerned with the presentation tier. These patterns are identified by Sun Java
Center.

### Name some design patterns which are used in JDK Library.

- Decorator pattern is used by Wrapper classes.
- Singleton pattern is used by Runtime, Calendar classes. (Also spring uses Singleton pattern by default)
- Factory pattern is used by Wrapper class like `Integer.valueOf()`.
- Observer pattern is used by event handling frameworks like swing, awt.

## TODO Rest of Design Patterns ##

## Lazy vs Eager

Eager loading loads the resource immediately while lazy loading loads the resource on demand

### N + 1 query problem

The N+1 query problem is said to occur when an ORM, like hibernate, executes 1 query to retrieve the parent entity and N
queries to retrieve the child entities. As the number of entities in the database increases, the queries being executed
separately can easily affect the performance of the application.

#### How to Fix N + 1 Query Problem?

##### EntityGraphs

EntityGraphs provides a way to formulate better performing queries by defining which entities need to be retrieved from
the database using SQL JOINS.

There are two types of EntityGraphs, Fetch and Load, which define if the entities not specified by attribute nodes of
EntityGraphs should be fetched lazily or eagerly. Attributes specified by attribute nodes of EntityGraph are always
fetched eagerly.

**FETCH TYPE**: Attributes that are specified by AttributeNodes of EntityGraph are treated as FetchType.EAGER and the
rest of the attributes are treated as FetchType.Lazy.

**LOAD TYPE**: Attributes that are specified by AttributeNodes of EntityGraph are treated as FetchType.EAGER and the
rest of the attributes are treated according to their specified or default FetchTypes.

##### SQL Joins

You can join queries so that you query every information you need so when you try to access the data, no additional
query will be needed.

##### Lazy fetch

You can also fetch these data lazily so that you will only query the data you need to access not query for N objects.

## Authentication vs Authorization

Authentication is identification, it is who you are.

Authorization is your access clearance, it is what you can do.

## What is a cross-cutting concern?

Let's assume that we have a web layer, a business layer, a data layer, and additional layers on top of that. However,
there are certain things that are related to all the layers. Things like authentication or logging which are
functionalities which would concern all the layers, and these kinds of functionalities are called cross-cutting
concerns. Performance tracking can also be a cross-cutting concern since you need to profile this in every layer of your
system. The best way to implement cross-cutting concerns is using Aspect Oriented Programming.

## LazyInitializationException

Hibernate throws this when it needs to initialize a lazily fetched association to another entity without an active
session context. Get authors with lists of books in them. Then try to access Book from author after the transaction
closes.

## @Bean vs @Component

- Bean is not auto detected, it is used to explicitly declare a single bean
- If any class is annotated with Component it will be automatically detected by using classpath scan

- Bean can be created even class is outside the spring container
- Component can't be created if class is outside spring container

- Bean is a method level annotation
- Component is a class level annotation

- @Configuration works only if the class is also annotated with it
- @Configuration is a class level annotation

- Use @Bean if we want a specific implementation based on dynamic condition
- We can't write specific implementation based on dynamic condition

## @Component, @Repository, @Service

- @Component is a generic stereotype for any Spring-managed component
- @Service annotates classes at the service layer.
- @Repository annotates classes at the persistence layer, which will act as a database repository.

### Component

- Spring will only pick up and register beans with @Component, and they are registered in ApplicationContext. @Component
  is the parent of all stereotype annotations

### Service

- We mark beans with @Service to indicate that they're holding the business logic.

### Repository

- @Repository’s job is to catch persistence-specific exceptions and re-throw them as one of Spring’s unified unchecked
  exceptions.
- For this, Spring provides PersistenceExceptionTranslationPostProcessor, which we are required to add in our
  application context (already included if we're using Spring Boot)

## @Component, @Repository, @Service summary

@Component generic stereotype for any Spring-managed component @Repository stereotype for persistence layer @Service
stereotype for service layer @Controller stereotype for presentation layer (spring-mvc)

## @ComponentScan

- @ComponentScan tells Spring in which packages you have annotated classes which should be managed by Spring.

## IoC (Inversion of Control)

Inversion of Control is a principle in software engineering which transfers the control of objects or portions of a
program to a container or framework. We most often use it in the context of object-oriented programming.

IoC enables a framework to take control of the flow of a program and make calls to our custom code.

The `Inversion-of-Control` (IoC) pattern, is about providing any kind of callback (which controls reaction), instead of
acting ourself directly (in other words, inversion and/or redirecting control to external handler/controller).
The `Dependency-Injection` (DI) pattern is a more specific version of IoC pattern, and is all about removing
dependencies from your code.

> Every `DI` implementation can be considered `IoC`, but one should not call it IoC, because implementing Dependency-Injection is harder than callback (Don't lower your product's worth by using general term "IoC" instead).

In the Spring framework, the interface ApplicationContext represents the IoC container. The Spring container is
responsible for instantiating, configuring and assembling objects known as beans, as well as managing their life cycles.

## Dependency Injection

Dependency injection is a pattern we can use to implement IoC, where the control being inverted is setting an object's
dependencies.

Connecting objects with other objects, or “injecting” objects into other objects, is done by an assembler rather than by
the objects themselves.

Dependency Injection in Spring can be done through constructors, setters or fields.

`@Autowired` allows us to inject dependencies via Spring.

## Java Thread Pool

A thread pool reuses previously created threads to execute current tasks and offers a solution to the problem of thread
cycle overhead and resource thrashing.

### Executor Thread Pool Methods

```
Method                          Description
newFixedThreadPool(int)         Creates a fixed size thread pool.
newCachedThreadPool()           Creates a thread pool that creates new threads as needed, but will reuse 
                                previously constructed threads when they are available
newSingleThreadExecutor()       Creates a single thread.
```

In case of a fixed thread pool, if all threads are being currently run by the executor then the pending tasks are placed
in a queue and are executed when a thread becomes idle.

### ScheduledThreadPoolExecutor

The ScheduledThreadPoolExecutor extends the ThreadPoolExecutor class and also implements the ScheduledExecutorService
interface with several additional methods:

```
schedule:               Allows us to run a task once after a specified delay.
scheduleAtFixedRate:    Allows us to run a task after a specified initial delay and then run it repeatedly with
                        a certain period. The period argument is the time measured between the starting times
                        of the tasks, so the execution rate is fixed.
scheduleWithFixedDelay: Similar to scheduleAtFixedRate in that it repeatedly runs the given task, but the specified
                        delay is measured between the end of the previous task and the start of the next. 
                        The execution rate may vary depending on the time it takes to run any given task.
```

### ForkJoinPool

ForkJoinPool is the central part of the fork/join framework introduced in Java 7. It solves a common problem of spawning
multiple tasks in recursive algorithms. We'll run out of threads quickly by using a simple ThreadPoolExecutor, as every
task or subtask requires its own thread to run.

In a fork/join framework, any task can spawn (fork) a number of subtasks and wait for their completion using the join
method. The benefit of the fork/join framework is that it does not create a new thread for each task or subtask, instead
implementing the work-stealing algorithm.

### Risks in using Thread Pools

1. `Deadlock` : While deadlock can occur in any multi-threaded program, thread pools introduce another case of deadlock,
   one in which all the executing threads are waiting for the results from the blocked threads waiting in the queue due
   to the unavailability of threads for execution.
2. `Thread Leakage` : Thread Leakage occurs if a thread is removed from the pool to execute a task but not returned to
   it when the task completed. As an example, if the thread throws an exception and pool class does not catch this
   exception, then the thread will simply exit, reducing the size of the thread pool by one. If this repeats many times,
   then the pool would eventually become empty and no threads would be available to execute other requests.
3. `Resource Thrashing` : If the thread pool size is very large then time is wasted in context switching between
   threads. Having more threads than the optimal number may cause starvation problem leading to resource thrashing as
   explained.

> The optimum size of the thread pool depends on the number of processors available and the nature of the tasks. On a N processor system for a queue of only computation type processes, a maximum thread pool size of N or N+1 will achieve the maximum efficiency.But tasks may wait for I/O and in such a case we take into account the ratio of waiting time(W) and service time(S) for a request; resulting in a maximum pool size of N*(1+ W/S) for maximum efficiency.

## Executors in Java

### Executor

The Executor interface has a single execute method to submit Runnable instances for execution.

### ExecutorService

The ExecutorService interface contains a large number of methods to control the progress of the tasks and manage the
termination of the service.

### ThreadPoolExecutor

The ThreadPoolExecutor is an extensible thread pool implementation with lots of parameters and hooks for fine-tuning.

> If all core threads are busy and the internal queue is full, the pool is allowed to grow up to maximumPoolSize.

## JPA Object Relational Mapping

Object Relational Mapping (ORM) is a functionality which is used to develop and maintain a relationship between an
object and relational database by mapping an object state to database column. It is capable to handle various database
operations easily such as inserting, updating, deleting etc.

![alt text](./img/jpa-object-relational-mapping.png "JPA ORM Schema")

#### ORM Framework

Hibernate is the framework that is mostly used for this job

### Mapping Directions

- Unidirectional relationship - In this relationship, only one entity can refer the properties to another. It contains
  only one owing side that specifies how an update can be made in the database.
- Bidirectional relationship - This relationship contains an owning side as well as an inverse side. So here every
  entity has a relationship field or refer the property to other entity.

### Types of Mapping

- One-to-one - This association is represented by `@OneToOne` annotation. Here, instance of each entity is related to a
  single instance of another entity.
- One-to-many - This association is represented by `@OneToMany` annotation. In this relationship, an instance of one
  entity can be related to more than one instance of another entity.
- Many-to-one - This mapping is defined by `@ManyToOne` annotation. In this relationship, multiple instances of an
  entity can be related to single instance of another entity.
- Many-to-many - This association is represented by `@ManyToMany` annotation. Here, multiple instances of an entity can
  be related to multiple instances of another entity. In this mapping, any side can be the owing side.

## @EqualsAndHashCode

Any class definition may be annotated with `@EqualsAndHashCode` to let lombok generate implementations of
the `equals(Object other)` and `hashCode()` methods. By default, it'll use all non-static, non-transient fields, but you
can modify which fields are used (and even specify that the output of various methods is to be used) by marking type
members with `@EqualsAndHashCode.Include` or `@EqualsAndHashCode.Exclude`. Alternatively, you can specify exactly which
fields or methods you wish to be used by marking them with `@EqualsAndHashCode.Include` and
using `@EqualsAndHashCode(onlyExplicitlyIncluded = true)`.

By setting `callSuper` to true, you can include the `equals` and `hashCode` methods of your superclass in the generated
methods. For `hashCode`, the result of `super.hashCode()` is included in the hash algorithm, and for `equals`, the
generated method will return false if the super implementation thinks it is not equal to the passed in object.

## Static vs Instance

`static` is for the cases where you don't want to have copy for each instance

`instance` variables are for the cases where you want separate copy for each instance of object.

### Static Properties

1. An instance variable is one per Object, every object has its own copy of instance variable.
2. A static variable is one per Class, every object of that class shares the same Static variable.
3. A static variable is initialized when the JVM loads the class.
4. A static method cannot access Non-static variable or method.
5. Static methods along with Static variables can mimic a Singleton Pattern, but IT'S NOT THE RIGHT WAY, as in when
   there are lots of classes, then we can't be sure about the class loading order of JVM, and this may create a problem.

## Polymorphism, Encapsulation, Abstraction and Inheritance

![alt text](./img/OOP-fundamentals.png "OOP Fundamentals")

### Inheritance

Inheritance ensures that codes are reused. Inheritance is an important pillar of OOP(Object-Oriented Programming). It is
the mechanism in java by which one class is allowed to inherit the features(fields and methods) of another class.

Important terminology:

- Super Class: The class whose features are inherited is known as superclass(or a base class or a parent class).
- Sub Class: The class that inherits the other class is known as a subclass(or a derived class, extended class, or child
  class). The subclass can add its own fields and methods in addition to the superclass fields and methods.
- Reusability: Inheritance supports the concept of “reusability”, i.e. when we want to create a new class and there is
  already a class that includes some of the code that we want, we can derive our new class from the existing class. By
  doing this, we are reusing the fields and methods of the existing class.

Types of Inheritance in Java

1. Single Inheritance (A extends B)
2. Multilevel Inheritance (A extends B extends C)
3. Hierarchical Inheritance (B extends A, C extends A, D extends A)
4. Multiple Inheritance (Only for interfaces) (A extends B, C)
5. Hybrid Inheritance (B extends A, C extends A, D extends B, C)

### Encapsulation

Hiding details from another class.

Encapsulation in Java is a mechanism of wrapping the data (variables) and code acting on the data (methods) together as
a single unit. In encapsulation, the variables of a class will be hidden from other classes, and can be accessed only
through the methods of their current class.

### Polymorphism

Polymorphism is the ability of an object to take on many forms. The most common use of polymorphism in OOP occurs when a
parent class reference is used to refer to a child class object.

Any Java object that can pass more than one **IS-A** test is considered to be polymorphic. In Java, all Java objects are
polymorphic since any object will pass the IS-A test for their own type and for the class Object.


> A Deer **IS-A** Animal\
> A Deer **IS-A** Vegetarian\
> A Deer **IS-A** Deer\
> A Deer **IS-A** Object

When we apply the reference variable facts to a Deer object reference, the following declarations are legal −

Example

```Java
Deer d = new Deer();
Animal a = d;
Vegetarian v = d;
Object o = d;
```

### Abstraction

Abstraction in Java is a programming methodology in which details of the programming codes are hidden away from the
user, and only the essential things are displayed to the user. Abstraction is concerned with ideas rather than events.
It’s like a user running a program (Web Browser) without seeing the background codes. Abstraction is achieved in either
Abstract classes or interface in Java.

### Composition

In object-oriented programming, we can use composition in cases where one object "has" (or is part of) another object.
Some examples would be:

- A car has a battery (a battery is part of a car).
- A person has a heart  (a heart is part of a person).
- A house has a living room (a living room is part of a house).

```Java
public class CompositionExample {
  public static void main(String... houseComposition) {
    new House(new Bedroom(), new LivingRoom());
    // The house now is composed with a Bedroom and a LivingRoom
  }

  static class House {
    Bedroom bedroom;
    LivingRoom livingRoom;

    House(Bedroom bedroom, LivingRoom livingRoom) {
      this.bedroom = bedroom;
      this.livingRoom = livingRoom;
    }
  }

    static class Bedroom { }
    static class LivingRoom { }
}
```

In this case, we know that a house has a living room and a bedroom, so we can use the Bedroom and LivingRoom objects in
the composition of a House.

## Composite

As a composite class, let's create a HeadDepartment class:

```Java
public class HeadDepartment implements Department {
  private Integer id;
  private String name;

  private List<Department> childDepartments;

  public HeadDepartment(Integer id, String name) {
    this.id = id;
    this.name = name;
    this.childDepartments = new ArrayList<>();
  }

  public void printDepartmentName() {
    childDepartments.forEach(Department::printDepartmentName);
  }

  public void addDepartment(Department department) {
    childDepartments.add(department);
  }

  public void removeDepartment(Department department) {
    childDepartments.remove(department);
  }
}
```

This is a composite class as **it holds a collection of Department components**, as well as methods for adding and
removing elements from the list.

The composite printDepartmentName() method is implemented by iterating over the list of leaf elements and invoking the
appropriate method for each one.

## Immutable classes

Immutable class in java means that once an object is created, we cannot change its content. In Java, all the wrapper
classes(like Integer, Boolean, Byte, Short) and String class is immutable. We can create our own immutable class as
well. Prior to going ahead do go through characteristics of immutability in order to have a good understanding while
implementing the same. Following are the requirements:

- The class must be declared as final so that child classes can’t be created.
- Data members in the class must be declared private so that direct access is not allowed.
- Data members in the class must be declared as final so that we can’t change the value of it after object creation.
- A parameterized constructor should initialize all the fields performing a deep copy so that data members can’t be
  modified with an object reference.
- Deep Copy of objects should be performed in the getter methods to return a copy rather than returning the actual
  object reference (*)

**Interview Question**:
You can still add contents to an ArrayList<> in Java even the field is created as private final. How can you make sure
your ArrayList<> is immutable?

**Answer**:
You should execute a deep copy in the getter method so the original List is not affected by it.

## Java Type System (Immutable Objects of Primitives)

Java has a two-fold type system consisting of primitives such as int, boolean and reference types such as Integer,
Boolean. Every primitive type corresponds to a reference type.

Every object contains a single value of the corresponding primitive type. `The wrapper classes are immutable` (so that
their state can't change once the object is constructed) and are `final` (so that we can't inherit from them).

The process of converting a primitive type to a reference one is called `autoboxing`, the opposite process is
called `unboxing`.

### Pros and Cons

#### Single Item Memory Footprint

The primitive type variables have the following impact on the memory:

- boolean – 1 bit
- byte – 8 bits
- short, char – 16 bits
- int, float – 32 bits
- long, double – 64 bits

It turns out that a single instance of a reference type on this JVM occupies 128 bits except for Long and Double which
occupy 192 bits:

- Boolean – 128 bits
- Byte – 128 bits
- Short, Character – 128 bits
- Integer, Float – 128 bits
- Long, Double – 192 bits

Surprisingly, arrays of the primitive types long and double consume more memory than their wrapper classes Long and
Double.

We can see either that **single-element arrays of primitive types are almost always more expensive (except for long and
double) than the corresponding reference type**.

The primitive types live in the stack while the reference types (Wrapper classes) live in the heap. This is a dominant
factor that determines how fast the objects get be accessed.

It's required more time to perform the operation for wrapper classes.

- Objects aren't passed around at all.
- Primitives and references are passed by value.
- If a method modifies an object, the modification is visible outside that method.

The `valueOf` method may create a new object, or it may return a reference to an object that existed previously. (In
fact, the JLS guarantees that `valueOf` will cache the `Integer` values for numbers in the range -128..+127 ...)

By contrast `new Integer(20)` always creates a new object.

This issue with new object (or not) is important if you are in the habit of comparing `Integer` wrapper objects (or
similar) using `==`. In one case `==` may be true if you compare two instances of "20". In the other case, it is
guaranteed to be `false`.

The lesson: use .equals(...) to compare wrapper types not `==`.

**Local Primitives** are stored on the **Stack**. Collections store their values via a reference to an Object's memory
location in the **Heap**.

## Public, Protected, default, Private

| Access Modifier | within class | within package | outside package by subclass only | outside package |
|-----------------|--------------|----------------|----------------------------------|-----------------|
| Private         | Y            | N              | N                                | N               |
| Default         | Y            | Y              | N                                | N               |
| Protected       | Y            | Y              | Y                                | N               |
| Public          | Y            | Y              | Y                                | Y               |

## Thread Safety in Java

We need to write implementations in a thread-safe way. This means that different threads can access the same resources
without exposing erroneous behavior or producing unpredictable results. This programming methodology is known as
“thread-safety”.

### How to Achieve It?

1. Stateless Implementations - simplest way
2. Immutable Implementations
3. Thread-Local Fields - create classes whose fields are thread-local by simply defining private fields in Thread
   classes.
4. Synchronized Collections
5. Concurrent Collections
6. Atomic Objects
7. Synchronized Methods
8. Synchronized Statements
9. Other Objects as a Lock
10. Volatile Fields
11. Reentrant Locks
12. Read/Write Locks

## SOLID

| Principle                       | Description                                                                                               |
|---------------------------------|-----------------------------------------------------------------------------------------------------------|
| Single Responsibility Principle | Each class should be responsible for a single part or functionality of the system.                        |
| Open-Closed Principle           | Software components should be open for extension, but not for modification.                               |
| Liskov Substitution Principle   | Objects of a superclass should be replaceable with objects of its subclasses without breaking the system. |
| Interface Segregation Principle | No client should be forced to depend on methods that it does not use.                                     |
| Dependency Inversion Principle  | High-level modules should not depend on low-level modules, both should depend on abstractions.            |

## Law of Demeter (LoD)

> Each unit should have only limited knowledge about other units: only units “closely” related to the current unit.
Each unit should only talk to its friends; don’t talk to strangers.
Only talk to your immediate friends.

What this basically means is that you should not obtain dependencies through your dependencies. You should not do things
like this.getA().getB().doSomething(). If you need dependency B, it should be provided to your class through its
constructor or as a method argument.

Breaking this principle makes the code highly-coupled to implementation details and substantially less reusable. It also
makes tests much harder to write because it requires you to mock or create instances of not only the explicit
collaborators of the class under test but also all the implicit chain of collaborators required by it.

## High Cohesion / Low Coupling

`Cohesion` in software engineering, as in real life, is how much the elements consisting a whole(in our case let's say a
class) can be said that they actually belong together. Thus, it is a measure of how strongly related each piece of
functionality expressed by the source code of a software module is.

`High Cohesion` (or the cohesion's best type - the functional cohesion) is when parts of a module are grouped because
they all contribute to a single well-defined task of the module.

`Coupling` in simple words, is how much one component (again, imagine a class, although not necessarily) knows about the
inner workings or inner elements of another one, i.e. how much knowledge it has of the other component.

`Loose coupling` is a method of interconnecting the components in a system or network so that those components, depend
on each other to the least extent practically possible…

- High cohesion: Elements within one class/module should functionally belong together and do one particular thing.
- Loose coupling: Among different classes/modules should be minimal dependency.

## ACID

| Principle   | Description                            |
|-------------|----------------------------------------|
| Atomicity   | All or Nothing transactions            |
| Consistency | Guarantees Committed Transaction State |
| Isolation   | Transactions are Independent           |
| Durability  | Committed Data is never lost           |

## What Is a Transaction?

Transactions in Java, as in general refer to a series of actions that must all complete successfully. Hence, if one or
more action fails, all other actions must back out leaving the state of the application unchanged.

In **JPA**, we can define regular classes as an `Entity` that provides them persistent identity. The `EntityManager`
class provides the necessary interface to work with multiple entities within a persistence context. The persistence
context can be thought of as a first-level cache where entities are managed

![alt text](./img/JPA-Architecture.webp "JPA Architecture")

The persistence context here can be of two types, transaction-scoped or extended-scoped. A transaction-scoped
persistence context is bound to a single transaction. While the extended-scoped persistence context can span across
multiple transactions. The **default scope of a persistence context is transaction-scope**.

### Transactions Support in Spring

Spring platform **provides us a much cleaner way of handling transactions, both resource local and global transactions**
in Java.

![alt text](./img/Spring-Transactions.jpg "Transactions in Spring")

Spring provides us this **seamless abstraction by creating a proxy for the methods** with transactional code. The proxy
manages the transaction state on behalf of the code with the help of `TransactionManager`.

The central interface here is `PlatformTransactionManager` which has a number of different implementations available. It
provides abstractions over JDBC (DataSource), JMS, JPA, JTA, and many other resources.

The easiest way to use transactions in Spring is with declarative support. Here, we have a **convenience annotation
available to be applied at the method or even at the class**. This simply enables global transaction for our code:

```Java
@PersistenceContext
EntityManager entityManager;

@Autowired
JmsTemplate jmsTemplate;

@Transactional(propagation = Propagation.REQUIRED)
public void process(ENTITY, MESSAGE) {
   entityManager.persist(ENTITY);
   jmsTemplate.convertAndSend(DESTINATION, MESSAGE);
}
```

### Transaction Propagation in Spring

Propagation defines our business logic's transaction boundary.

Spring manages to start and pause a transaction according to our propagation setting.

Spring calls TransactionManager::getTransaction to get or create a transaction according to the propagation. It supports
some of the propagations for all types of TransactionManager, but there are a few of them that are only supported by
specific implementations of TransactionManager.

#### REQUIRED Propagation

REQUIRED is the default propagation. Spring checks if there is an active transaction, and if nothing exists, it creates
a new one. Otherwise, the business logic appends to the currently active transaction.

#### SUPPORTS Propagation

For SUPPORTS, Spring first checks if an active transaction exists. If a transaction exists, then the existing
transaction will be used. If there isn't a transaction, it is executed non-transactional.

#### MANDATORY Propagation

When the propagation is MANDATORY, if there is an active transaction, then it will be used. If there isn't an active
transaction, then Spring throws an exception: `IllegalTransactionStateException`

#### NEVER Propagation

For transactional logic with NEVER propagation, Spring throws an exception if there's an active
transaction: `IllegalTransactionStateException`;

#### NOT_SUPPORTED Propagation

If a current transaction exists, first Spring suspends it, and then the business logic is executed without a
transaction.

#### REQUIRES_NEW Propagation

When the propagation is REQUIRES_NEW, Spring suspends the current transaction if it exists, and then creates a new one.

#### NESTED Propagation

For NESTED propagation, Spring checks if a transaction exists, and if so, it marks a save point. This means that if our
business logic execution throws an exception, then the transaction rollbacks to this save point. If there's no active
transaction, it works like REQUIRED.

### Transaction Isolation in Spring

Isolation is one of the common ACID properties: Atomicity, Consistency, Isolation, and Durability. Isolation describes
how changes applied by concurrent transactions are visible to each other.

#### ISOLATION LEVELS

#### DEFAULT:

The default isolation level is DEFAULT. As a result, when Spring creates a new transaction, the isolation level will be
the default isolation of our RDBMS. Therefore, we should be careful if we change the database.

We should also consider cases when we call a chain of methods with different isolation. In the normal flow, the
isolation only applies when a new transaction is created. Thus, if for any reason we don't want to allow a method to
execute in different isolation, we have to set `TransactionManager::setValidateExistingTransaction` to true.

#### READ_UNCOMMITTED Isolation

READ_UNCOMMITTED is the lowest isolation level and allows for the most concurrent access. As a result, it suffers from
all three mentioned concurrency side effects. A transaction with this isolation reads uncommitted data of other
concurrent transactions.

#### READ_COMMITTED Isolation

The second level of isolation, READ_COMMITTED, prevents dirty reads.

The rest of the concurrency side effects could still happen. So uncommitted changes in concurrent transactions have no
impact on us, but if a transaction commits its changes, our result could change by re-querying.

#### REPEATABLE_READ Isolation

The third level of isolation, REPEATABLE_READ, prevents dirty, and non-repeatable reads. So we are not affected by
uncommitted changes in concurrent transactions.

Also, when we re-query for a row, we don't get a different result. However, in the re-execution of range-queries, we may
get newly added or removed rows.

Moreover, it is the lowest required level to prevent the lost update. The lost update occurs when two or more concurrent
transactions read and update the same row. REPEATABLE_READ does not allow simultaneous access to a row at all. Hence the
lost update can't happen.

#### SERIALIZABLE Isolation

SERIALIZABLE is the highest level of isolation. It prevents all mentioned concurrency side effects, but can lead to the
lowest concurrent access rate because it executes concurrent calls sequentially.

In other words, concurrent execution of a group of serializable transactions has the same result as executing them in
serial.

### Database Isolation Level

Problem:

- Dirty Read – A Dirty read is a situation when a transaction reads data that has not yet been committed. For example,
  Let’s say transaction 1 updates a row and leaves it uncommitted, meanwhile, Transaction 2 reads the updated row. If
  transaction 1 rolls back the change, transaction 2 will have read data that is considered never to have existed.
- Non Repeatable read – Non Repeatable read occurs when a transaction reads the same row twice and gets a different
  value each time. For example, suppose transaction T1 reads data. Due to concurrency, another transaction T2 updates
  the same data and commit, Now if transaction T1 rereads the same data, it will retrieve a different value.
- Phantom Read – Phantom Read occurs when two same queries are executed, but the rows retrieved by the two, are
  different. For example, suppose transaction T1 retrieves a set of rows that satisfy some search criteria. Now,
  Transaction T2 generates some new rows that match the search criteria for transaction T1. If transaction T1
  re-executes the statement that reads the rows, it gets a different set of rows this time.

#### ISOLATION LEVELS:

1. **Read Uncommitted** – Read Uncommitted is the lowest isolation level. In this level, one transaction may read not
   yet committed changes made by other transactions, thereby allowing dirty reads. At this level, transactions are not
   isolated from each other.
2. **Read Committed** – This isolation level guarantees that any data read is committed at the moment it is read. Thus
   it does not allow dirty read. The transaction holds a read or write lock on the current row, and thus prevents other
   transactions from reading, updating, or deleting it.
3. **Repeatable Read** – This is the most restrictive isolation level. The transaction holds read locks on all rows it
   references and writes locks on referenced rows for update and delete actions. Since other transactions cannot read,
   update or delete these rows, consequently it avoids non-repeatable read.
4. **Serializable** – This is the highest isolation level. A serializable execution is guaranteed to be serializable.
   Serializable execution is defined to be an execution of operations in which concurrently executing transactions
   appears to be serially executing.
5. **Snapshot**:  This isolation level can occur some performance issues because of increasing concurrent working. Every
   transaction has their own snapshot, and they work with their own data. -- Update Conflict

## Composition vs Inheritance

The `composition` is a design technique in which your class can have an instance of another class as a field of your
class. `Inheritance` is a mechanism under which one object can acquire the properties and behavior of the parent object
by extending a class.

`Composition` and `Inheritance` both provide code reusability by relating class. We can also get the functionality
of `inheritance` when you use `composition`. Below are the differences.

| Key        | Inheritance                                                                                                           | Composition                                              |
|------------|-----------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------|
| Basic      | Inheritance is an "is-a" relationship                                                                                 | Composition is a "has-a" relationship                    |
| Code Reuse | In Inheritance, a class lass can extend only one interface, therefore, you can reuse your code only in one class only | We can reuse code in multiple class                      |
| Scope      | Inheritance provides its features at compile time                                                                     | Composition is easily achieved at runtime                |
| Final      | We can’t reuse code from the final class                                                                              | It allows code reuse even from final classes             |
| Methods    | It exposes both public and protected method of the parent class                                                       | It doesn’t expose. They interact using public interface. |

#### Example of Inheritance

```Java
class Animal{
   String name="Orio";
}

class Dog extends Animal{
   String type="Dog";
   public static void main(String args[]){
      Dog p=new Dog();
      System.out.println("Name:"+p.name);
      System.out.println("Type:"+p.type);
   }
}
```

#### Example of Composition

```Java
public class Student {
}

public class College {
   private Student student;
   public College() {
      this.student = new Student();
   }
}
```

## NoSQL vs Relational Database

The main objective of a NoSQL database is to have the following three things:

- Simplicity of design
- Horizontal scaling
- High availability

NoSQL is faster than relational database management system because it uses different data structure compared to
relational databases.

### Differences between NoSQL and Relational database

| NoSQL Database                                                                 | Relational Database                                                                              |
|--------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------|
| NoSQL Database supports a very simple query language                           | Relational Database supports a powerful query language                                           |
| NoSQL Database has no fixed schema                                             | Relational Database has a fixed schema                                                           |
| NoSQL Database is only eventually consistent                                   | Relational Database follows acid properties. (Atomicity, Consistency, Isolation, and Durability) |
| NoSQL databases don't support transactions (support only simple transactions). | Relational Database supports transactions (also complex transactions with joins).                |
| NoSQL Database is used to handle data coming in high velocity                  | Relational Database is used to handle data coming in low velocity                                |
| The NoSQL's data arrive from many locations                                    | Data in relational database arrive from one or few locations                                     |
| NoSQL database can manage structured, unstructured and semi-structured data    | Relational database manages only structured data                                                 |
| NoSQL databases have no single point of failure                                | Relational databases have a single point of failure with failover                                |
| NoSQL databases can handle big data or data in a very high volume              | NoSQL databases are used to handle moderate volume of data                                       |
| NoSQL has decentralized structure                                              | Relational database has centralized structure                                                    |
| NoSQL database gives both read and write scalability                           | Relational database gives read scalability only                                                  |
| NoSQL database is deployed in horizontal fashion                               | Relation database is deployed in vertical fashion                                                |

## Polling vs SSE vs Websocket

- Long/short polling (client pull)
- WebSockets (server push)
- Server-Sent Events (server push)

`Client pull` — client asking server for updates at certain regular intervals

`Server push` — server is proactively pushing updates to the client (reverse of client pull)

![alt text](./img/polling_sse_comparison.png "Polling vs SSE")

`Polling` is a technique by which the client asking the server for new data regularly. We can do polling in two
ways: `Short Polling` and `Long Polling`.

> `Short polling` is an AJAX-based timer that calls at fixed delays. Lot of request that are processed as they come on server. Creates a lot of traffic (uses resources, but frees them as soon as response is send back):

> `Long polling` is based on Comet (i.e server will send data to the client when the server event happens with no delay). One request goes to server and client is waiting for the response to come (its unresolved). In case of Server with php/apache would mean a spawned thread to handle, that reserve resources, till its done. So the traffic is smaller, but you eat up your resources fast (or rather you block resources).

> `Websocket` - First call is size of http request, but later you send just the messages, from the client to server (new questions) and server to client(answers or pushes - can even do broadcast for all connected clients).

> `SSE` (Server Send Event) is a mechanism that allows the server to asynchronously push the data to the client once the client-server connection is established. The server can then decide to send data whenever a new “chunk” of data is available. It can be considered as a one-way `publish-subscribe` model.

The main benefits we get from SSE approach are:

- Simpler implementation and Data efficiency
- It is automatically multiplexed over HTTP/2 out of the box
- Limits the number of connections for data on the client to one

### When to use

- Short polling - well, never.

- Long polling 
  - Potentially when you are exchanging single call with server, and server is doing some work in background.
  - When you won't query server on the same page anymore.
  - When you are not using php as layer to handle the long polled connection (node/c++ can be a simple middle layer). 

> Note long polling can be really beneficial, but only when you make it so.

- Websocket 
  - You potentially will exchange more then one or two calls with server, or something might come from server you did not expected / asked, like notification of email or something.
  - You should plan different "rooms", depend on functionalities.
    
- SSE
  - If your use case requires displaying real-time market news, market data, chat applications, etc., like in our case relying on HTTP/2 + SSE will provide you with an efficient bi-directional communication channel while reaping the benefits from staying in the HTTP world.

Example for SSE usages

- A real-time chart of streaming stock prices
- Real-time news coverage of an important event (posting links, tweets, and images)
- A live Github / Twitter dashboard wall fed by Twitter’s streaming API
- A monitor for server statistics like uptime, health, and running processes.

## Bean Scopes

The latest version of the Spring framework defines 6 types of scopes:

- singleton
- prototype
- request (web-aware application)
- session (web-aware application)
- application (web-aware application)
- websocket (web-aware application)

### Singleton Scope

When we define a bean with the `singleton scope`, the container creates a single instance of that bean; all requests for
that bean name will return the same object, which is `cached`. Any modifications to the object will be reflected in all
references to the bean. This scope is the `default value` if no other scope is specified.

### Prototype Scope

A bean with the prototype scope will return a different instance every time it is requested from the container. It is
defined by setting the value prototype to the @Scope annotation in the bean definition

### Request scope

Creates a bean instance for a single HTTP request

### Session scope

Creates a bean instance for an HTTP Session.

### Application scope

Creates the bean instance for the lifecycle of a `ServletContext`.

### Websocket scope

Creates it for a particular `WebSocket` session.

## Monolithic vs Microservice

### Monolithic Pros vs Cons

| Advantages                                                                                                                      | Disadvantages                                                                                                                                                                                                                                                                                 |
|---------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Simple to develop relative to microservices where skilled developers are required in order to identify and develop the services | It becomes too large in size with time and hence, difficult to manage                                                                                                                                                                                                                         |
| Easier to deploy as only a single jar/war file is deployed                                                                      | We need to redeploy the whole application even for a small change                                                                                                                                                                                                                             |
| Relatively easier and simple to develop in comparison to microservices architecture                                             | As the size of the application increases, its start-up and deployment time also increases                                                                                                                                                                                                     |
| The problems of network latency and security are relatively less in comparison to microservices architecture                    | For any new developer joining the project, it is very difficult to understand the logic of large Monolithic application even if his responsibility is related to a single functionality                                                                                                       |
|                                                                                                                                 | Even if a single part of the application is facing a large load/traffic, we need to deploy the instances of the whole application in multiple servers. It is very inefficient and takes up more resources unnecessarily. Hence, horizontal scaling is not feasible in monolithic applications |
|                                                                                                                                 | It is very difficult to adopt any new technology which is well suited for a particular functionality as it affects the whole application, both in terms of time and cost                                                                                                                      |
|                                                                                                                                 | It is not very reliable as a single bug in any module can bring down the whole monolithic application                                                                                                                                                                                         |

### Microservices Pros and Cons

| Advantages                                                                                                                                                                                                                  | Disadvantages                                                                                                                                           |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|
| It is easy to manage as it is relatively smaller in size                                                                                                                                                                    | Being a distributed system, it is much more complex than monolithic applications. Its complexity increases with the increase in number of microservices |
| If there’s any update in one of the microservices, then we need to redeploy only that microservice                                                                                                                          | Skilled developers are required to work with microservices architecture which can identify the microservices and manage their inter-communications      |
| Microservices are self-contained and hence, deployed independently. Their start-up and deployment time are relatively less                                                                                                  | Independent deployment of microservices is complicated                                                                                                  |
| It is very easy for a new developer to on-board the project as he needs to understand only a particular microservice providing the functionality he will be working on and not the whole system                             | Microservices are costly in terms of network usage as they need to interact with each other and all these remote calls results into network latency     |
| If a particular microservice is facing a large load because of the users using that functionality in excess then we need to scale out that microservice only. Hence, microservices architecture supports horizontal scaling | Microservices are less secure relative to monolithic applications due to the inter-services communication over the network                              |
| Each microservice can use different technology based on the business requirements                                                                                                                                           | Debugging is difficult as the control flows over many microservices and to point out why and where exactly the error occurred is a difficult task.      |
| If a particular microservice goes down due to some bug, then it doesn’t affect other microservices and the whole system remains intact, continues providing other functionalities to the users                              |                                                                                                                                                         |

## REST

REST stands for representational state transfer and a REST API (also known as RESTful API) is an application programming
interface (API or web API) that conforms to the constraints of REST architectural style and allows for interaction with
RESTful web services. (Which uses Spring MVC)

By building on top of HTTP, REST APIs provide the means to build:

- Backwards compatible APIs
- Evolvable APIs
- Scaleable services
- Securable services
- A spectrum of stateless to stateful services

To handle basic CRUD operations, there are HTTP methods that we can use:

| HTTP Verb | CRUD                                                      | Idempotent | Safe |
|-----------|-----------------------------------------------------------|------------|------|
| `POST`    | Create                                                    | N          | N    |
| `GET`     | Read                                                      | Y          | Y    |
| `PUT`     | Update/Replace                                            | Y          | N    |
| `PATCH`   | Update/Modify                                             | Y/N        | N    |
| `DELETE`  | Delete                                                    | Y          | N    |
| `OPTIONS` | returns info about API (methods/content type)             | Y          | Y    |
| `HEAD`    | returns info about resource (version/length/type)         | Y          | Y    |
| `TRACE`   | Performs a loop-back test                                 | Y          | N    |
| `CONNECT` | starts two-way communications with the requested resource | N          | N    |

```
x + 0;
x = 5;
```

The first of these, adding zero, will return the same value every time (it is idempotent), and adding zero will have no
effect on that value (it is also safe). The second example will return the same value every time (it is idempotent) but
is not safe (if x is anything other than 5 before the operation runs, it changes x).

To a method to be safe it should not modify the value.

Other than `POST` and `CONNECT` method every method is idempotent. `PATCH` is not idempotent but can be.

### Why is PATCH not idempotent

It's not safe because in general you can't safely execute a `PATCH` request without changing a resource (That's what it'
s for).

So why is `PATCH` not idempotent compared to `PUT`? It's because it matters how you apply your changes. If you'd like to
change the name property of a resource, you might send something like `{"name": "foo"}` as a payload and that would
indeed be idempotent since executing this request any number of times would yield the same result: The resources name
attribute is now "foo".

But `PATCH` is much more general in how you can change a resource (check this definition on how to apply a JSON patch).
It could also, for example, mean to move the resource and would look something like
this: `{ "op": "move", "from": "/a/b/c", "path": "/a/b/d" }`. This operation is obviously not idempotent since calling
at a second time would result in an error.

### PUT vs PATCH

PUT is a method of modifying resource where the client sends data that updates the entire resource .

PATCH is a method of modifying resources where the client sends partial data that is to be updated without modifying the
entire data.

### Path params vs Query params

Best practice for RESTful API design is that path params are used to identify a specific resource or resources, while
query parameters are used to sort/filter those resources.

Here's an example. Suppose you are implementing RESTful API endpoints for an entity called Car. You would structure your
endpoints like this:

GET /cars GET /cars/:id POST /cars PUT /cars/:id DELETE /cars/:id

This way you are only using path parameters when you are specifying which resource to fetch, but this does not
sort/filter the resources in any way.

Now suppose you wanted to add the capability to filter the cars by color in your GET requests. Because color is not a
resource (it is a property of a resource), you could add a query parameter that does this. You would add that query
parameter to your GET /cars request like this:

GET /cars?color=blue

This endpoint would be implemented so that only blue cars would be returned.

> A car is a very tangible object that has attributes like make, model and VIN - that never changes, and color, suspension etc. that may change over time. So if we encode the URI with attributes that may change over time (temporal), we may end up with multiple URIs for the same object:
>
> `GET /cars/honda/civic/coupe/{vin}/{color=red}`
>
> And years later, if the color of this very same car is changed to black:
>
> `GET /cars/honda/civic/coupe/{vin}/{color=black}`
>
> Note that the car instance itself (the object) has not changed - it's just the color that changed. Having multiple URIs pointing to the same object instance will force you to create multiple URI handlers - this is not an efficient design, and is of course not intuitive.
>
> Therefore, the URI should only consist of parts that will never change and will continue to uniquely identify that resource throughout its lifetime. Everything that may change should be reserved for query parameters, as such:
>
> `GET /cars/honda/civic/coupe/{vin}?color={black}`
>
> Bottom line - think polymorphism.

## Spring vs Spring Boot in a nutshell

- In the Spring framework, you have to build configurations manually.
- In Spring Boot there are default configurations that allow faster bootstrapping.
- Spring Framework requires a number of dependencies to create a web app.
- Spring Boot, on the other hand, can get an application working with just one dependency.

## SQL Injection

SQL injection, also known as SQLI, is a common attack vector that uses malicious SQL code for backend database
manipulation to access information that was not intended to be displayed. JPA does not prevent it.

### How to prevent it?

- **Parameterized Queries** - prepared statements with the question mark placeholder (“?”) in queries
- **JPA Criteria API** - `CriteriaBuilder`
- **User Data Sanitization** - (Validation by Blacklists and Whitelists) Data Sanitization is a technique of applying a
  filter to user supplied-data so it can be safely used by other parts of our application.

### What other SQL injections are there?

- Stored Procedures: These are also prone to SQL Injection issues
- Triggers: Same issue as with procedure calls
- Insecure Direct Object References: The main point here is related to different ways an attacker can trick the
  application, so it returns records he or she was not supposed to have access to

## JPA vs Hibernate

JPA is the interface while Hibernate is the implementation.

| JPA                                                                                                                                                                   | Hibernate                                                                                                                                                                            |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Java Persistence API (JPA) defines the management of relational data in the Java applications.                                                                        | Hibernate is an Object-Relational Mapping (ORM) tool which is used to save the state of Java object into the database.                                                               |
| It is just a specification. Various ORM tools implement it for data persistence.                                                                                      | It is one of the most frequently used JPA implementation.                                                                                                                            |
| It is defined in javax.persistence package.                                                                                                                           | It is defined in org.hibernate package.                                                                                                                                              |
| The EntityManagerFactory interface is used to interact with the entity manager factory for the persistence unit. Thus, it provides an entity manager.                 | It uses SessionFactory interface to create Session instances.                                                                                                                        |
| It uses EntityManager interface to create, read, and delete operations for instances of mapped entity classes. This interface interacts with the persistence context. | It uses Session interface to create, read, and delete operations for instances of mapped entity classes. It behaves as a runtime interface between a Java application and Hibernate. |
| It uses Java Persistence Query Language (JPQL) as an object-oriented query language to perform database operations.                                                   | It uses Hibernate Query Language (HQL) as an object-oriented query language to perform database operations.                                                                          |

**JPA** : is just like an interface and have no concrete implementation of it to use functions which are there in JPA.
**Hibernate** : is just a JPA Provider which have the implementation of the functions in JPA and can have some extra
functions which might not be there in JPA.

## What is JSON Web Token (JWT)?

`JSON Web Token` (JWT) is an open standard (RFC 7519) that defines a compact and self-contained way for securely
transmitting information between parties as a `JSON` object. This information can be verified and trusted because it is
digitally signed. `JWT`s can be signed using a secret (with the **HMAC** algorithm) or a public/private key pair
using **RSA** or **ECDSA**.

### When should you use JSON Web Tokens?

- **Authorization**: This is the most common scenario for using JWT. Once the user is logged in, each subsequent request
  will include the JWT, allowing the user to access routes, services, and resources that are permitted with that token.
  Single Sign On is a feature that widely uses JWT nowadays, because of its small overhead and its ability to be easily
  used across different domains.
- **Information Exchange**: JSON Web Tokens are a good way of securely transmitting information between parties. Because
  JWTs can be signed—for example, using public/private key pairs—you can be sure the senders are who they say they are.
  Additionally, as the signature is calculated using the header and the payload, **you can also verify that the content
  hasn't been tampered with**.

### What is the JSON Web Token structure?

In its compact form, JSON Web Tokens consist of three parts separated by dots (.), which are:

- Header
- Payload
- Signature

Therefore, a JWT typically looks like the following.

xxxxx.yyyyy.zzzzz

Let's break down the different parts.

#### Header

The header typically consists of two parts: the type of the token, which is JWT, and the signing algorithm being used,
such as HMAC SHA256 or RSA.

For example:

```
{
  "alg": "HS256",
  "typ": "JWT"
}
```

Then, this JSON is `Base64Url` encoded to form the first part of the JWT.

#### Payload

The second part of the token is the payload, which contains the **claims**. Claims are statements about an entity (
typically, the user) and additional data. There are three types of claims:

- Registered
- Public
- Private

##### Registered claims

These are a set of predefined claims which are not mandatory but recommended, to provide a set of useful, interoperable
claims. Some of them are: iss (issuer), exp (expiration time), sub (subject), aud (audience), and others. Notice that
the claim names are only three characters long as JWT is meant to be compact.

##### Public claims

These can be defined at will by those using JWTs. But to avoid collisions they should be defined in the IANA JSON Web
Token Registry or be defined as a URI that contains a collision resistant namespace.

##### Private claims

These are the custom claims created to share information between parties that agree on using them and are neither
registered nor public claims.

An example payload could be:

```
{
  "sub": "1234567890",
  "name": "John Doe",
  "admin": true
}
```

The payload is then `Base64Url` encoded to form the second part of the JSON Web Token.

Do note that for signed tokens this information, though protected against tampering, is readable by anyone. Do not put
secret information in the payload or header elements of a JWT unless it is encrypted.

#### Signature

To create the signature part you have to take the encoded header, the encoded payload, a secret, the algorithm specified
in the header, and sign that.

For example if you want to use the HMAC SHA256 algorithm, the signature will be created in the following way:

```
HMACSHA256(
 base64UrlEncode(header) + "." +
 base64UrlEncode(payload),
 secret)
```

The signature is used to verify the message wasn't changed along the way, and, in the case of tokens signed with a
private key, it can also verify that the sender of the JWT is who it says it is.

### How do JSON Web Tokens work?

In authentication, when the user successfully logs in using their credentials, a JSON Web Token will be returned. Since
tokens are credentials, great care must be taken to prevent security issues. In general, you should not keep tokens
longer than required.

**You also should not store sensitive session data in browser storage due to lack of security**.

Whenever the user wants to access a protected route or resource, the user agent should send the JWT, typically in
the `Authorization` header using the `Bearer` schema. The content of the header should look like the following:

```
Authorization: Bearer <token>
```

This can be, in certain cases, a stateless authorization mechanism. The server's protected routes will check for a valid
JWT in the `Authorization` header, and if it's present, the user will be allowed to access protected resources. If the
JWT contains the necessary data, the need to query the database for certain operations may be reduced, though this may
not always be the case.

If the token is sent in the `Authorization` header, `Cross-Origin Resource Sharing (CORS)` won't be an issue as it
doesn't use cookies.

### Why should we use JSON Web Tokens?

Let's talk about the benefits of JSON Web Tokens (JWT) when compared to Simple Web Tokens (SWT) and Security Assertion
Markup Language Tokens (SAML).

As JSON is less verbose than XML, when it is encoded its size is also **smaller**, making JWT more compact than SAML.
This makes JWT a good choice to be passed in HTML and HTTP environments.

### JWT can't be modified. How?

JWTs can be either signed, encrypted or both. If a token is signed, but not encrypted, everyone can read its contents,
but when you don't know the `private key`, you can't change it. Otherwise, the receiver will notice that the signature
won't match anymore. Server knows and holds the private key so even if modified server will invalidate it if the client
tampered with the token.

## SQL Index

Indexing is the way to get an unordered table into an order that will maximize the query’s efficiency while searching.

### How does it work?

Database creates a `B-Tree` (generally) in order to sort the column and that column only. Database indexes will also
store pointers which are simply reference information for the location of the additional information in memory.
Basically the index holds the id and that particular row’s home address on the memory disk.

![alt text](./img/indexed-table.png "Indexed Table")

### Types of Indexing

There are basically three main types of indexing methods:

- Primary Indexing
- Secondary Indexing
- Clustering Index

![alt text](./img/db-index-types.png "DB Index Types")

#### Primary Index

Primary Index is an ordered file which is fixed length size with two fields. The first field is the same a primary key
and second, filed is pointed to that specific data block. In the primary Index, there is always one to one relationship
between the entries in the index table.

The primary Indexing in DBMS is also further divided into two types:

- Dense Index
- Sparse Index

##### Dense Index

In a dense index, a record is created for every search key valued in the database. This helps you to search faster but
needs more space to store index records. In this Indexing, method records contain search key value and points to the
real record on the disk.

![alt text](./img/dense-index.png "Dense Index")

##### Sparse Index

It is an index record that appears for only some of the values in the file. Sparse Index helps you to resolve the issues
of dense Indexing in DBMS. In this method of indexing technique, a range of index columns stores the same data block
address, and when data needs to be retrieved, the block address will be fetched.

However, sparse Index stores index records for only some search-key values. It needs less space, less maintenance
overhead for insertion, and deletions but It is slower compared to the dense Index for locating records.

![alt text](./img/sparse-index.png "Sparse Index")

#### Secondary Index

The secondary Index in DBMS can be generated by a field which has a unique value for each record, and it should be a
candidate key. It is also known as a non-clustering index.

This two-level database indexing technique is used to reduce the mapping size of the first level. For the first level, a
large range of numbers is selected because of this; the mapping size always remains small.

![alt text](./img/secondary-index.png "Secondary Index")

#### Composite Index

If you have more than one columns indexed together, then it is a composite index.

```
CREATE INDEX class_pos_index ON users (class, position);
```

#### Clustering Index

In a clustered index, records themselves are stored in the Index and not pointers. Sometimes the Index is created on
non-primary key columns which might not be unique for each record. In such a situation, you can group two or more
columns to get the unique values and create an index which is called clustered Index. This also helps you to identify
the record faster.

Example:
Let’s assume that a company recruited many employees in various departments. In this case, clustering indexing in DBMS
should be created for all employees who belong to the same dept.

##### Clustered vs Non-Clustered Index

KEY DIFFERENCE

- Cluster index is a type of index that sorts the data rows in the table on their key values whereas the Non-clustered
  index stores the data at one location and indices at another location.
- Clustered index stores data pages in the leaf nodes of the index while Non-clustered index method never stores data
  pages in the leaf nodes of the index.
- Cluster index doesn’t require additional disk space whereas the Non-clustered index requires additional disk space.
- Cluster index offers faster data accessing, on the other hand, Non-clustered index is slower.

**Characteristic of Clustered Index**

- Default and sorted data storage
- Use just one or more than one columns for an index
- Helps you to store Data and index together
- Fragmentation
- Operations
- Clustered index scan and index seek
- Key Lookup

**Characteristics of Non-clustered Indexes**

- Store key values only
- Pointers to Heap/Clustered Index rows
- Allows Secondary data access
- Bridge to the data
- Operations of Index Scan and Index Seek
- You can create a nonclustered index for a table or view
- Every index row in the nonclustered index stores the nonclustered key value and a row locator

![alt text](./img/Clustered_Index.jpg "Clustered Index Example")

![alt text](./img/Non-clustered_Index.jpg "Non-Clustered Index Example")

###### Differences between Clustered Index and NonClustered Index

| Parameters            | Clustered                                                                                 | Non-clustered                                                                                                       |
|-----------------------|-------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------|
| Use for               | You can sort the records and store clustered index physically in memory as per the order. | A non-clustered index helps you to creates a logical order for data rows and uses pointers for physical data files. |
| Storing method        | Allows you to stores data pages in the leaf nodes of the index.                           | This indexing method never stores data pages in the leaf nodes of the index.                                        |
| Size                  | The size of the clustered index is quite large.                                           | The size of the non-clustered index is small compared to the clustered index.                                       |
| Data accessing        | Faster                                                                                    | Slower compared to the clustered index                                                                              |
| Additional disk space | Not Required                                                                              | Required to store the index separately                                                                              |
| Type of key           | By Default Primary Keys Of The Table is a Clustered Index.                                | It can be used with unique constraint on the table which acts as a composite key.                                   |
| Main feature          | A clustered index can improve the performance of data retrieval.                          | It should be created on columns which are used in joins.                                                            |

### Pros and Cons of Indexing

| Pros                                                                                                                                                                                          | Cons                                                                                                         |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------|
| It helps you to reduce the total number of I/O operations needed to retrieve that data, so you don’t need to access a row in the database from an index structure.                            | To perform the indexing database management system, you need a primary key on the table with a unique value. |
| Offers Faster search and retrieval of data to users.                                                                                                                                          | You can’t perform any other indexes in Database on the Indexed data.                                         |
| Indexing also helps you to reduce tablespace as you don’t need to link to a row in a table, as there is no need to store the ROWID in the Index. Thus you will able to reduce the tablespace. | You are not allowed to partition an index-organized table.                                                   |
| You can’t sort data in the lead nodes as the value of the primary key classifies it.                                                                                                          | SQL Indexing Decrease performance in INSERT, DELETE, and UPDATE query.                                       |

## Idempotency

Idempotent operations produce the same result even when the operation is repeated many times. The result of the 2nd,
3rd, and 1,000th repeat of the operation will return exactly the same result as the 1st time.

## How to write Quality Code

1. Well-indented
2. Descriptive Names
3. Comment and Document
4. Don't Repeat Yourself (DRY)
5. Keep It Simple Stupid / Keep It Super Simple / Keep It Short and Simple (KISS)
6. Check for Errors and Respond to Them
7. Split your code into short, focused units
8. Use Framework APIs and Third-Party Libraries (No need to reinvent the wheel)
9. Don't Overdesign
10. Be consistent
11. Avoid Security Pitfalls
12. User efficient Data Structures and Algorithms
13. Include Unit tests
14. Keep your code portable (Run everywhere)
15. Make your code buildable (Single command to get ready for distribution)
16. Put everything under version control (GitHub)
17. Lower Technical Debt

### How to measure code quality?

1. Reliability
2. Maintainability
3. Testability
4. Portability
5. Reusability

### How to maintain code quality?

1. Use a coding standard
2. Analyze code - before code reviews
3. Code Reviews
4. Follow code review best practices
5. Refactor legacy code (when necessary)
6. Use SonarQube like third-party applications
7. Write testable code

## Unit Testing Vs Integration Testing Vs Functional Testing

### Unit testing

Means testing individual modules of an application in isolation (without any interaction with dependencies) to confirm
that the code is doing things right.

### Integration testing

Means checking if different modules are working fine when combined together as a group.

### Functional testing

Means testing a slice of functionality in the system (may interact with dependencies) to confirm that the code is doing
the right things.

Functional tests are related to integration tests, however, they signify to the tests that check the entire
application’s functionality with all the code running together, nearly a super integration test.

![alt text](./img/unit-testing-vs-functional-testin.webp "Testing Hierarchy")

## Java default methods

Java 8 release included default methods.

Like regular interface methods, default methods are implicitly public; there's no need to specify the public modifier.

Unlike regular interface methods, we declare them with the default keyword at the beginning of the method signature, and
they provide an implementation

In a typical design based on abstractions, where an interface has one or multiple implementations, if one or more
methods are added to the interface, all the implementations will be forced to implement them too. Otherwise, the design
will just break down.

Default interface methods are an efficient way to deal with this issue. They **allow us to add new methods to an
interface that are automatically available in the implementations**. Therefore, we don't need to modify the implementing
classes.

In this way, **backward compatibility is neatly preserved** without having to refactor the implementers.

### What happens when a class implements several interfaces that define the same _default_ methods.

- We must explicitly provide an implementation for the methods.
- We can have our class use the default methods of one of the interfaces

To use both methods:

```Java
@Override
public String turnAlarmOn() {
  return Vehicle.super.turnAlarmOn() + " " + Alarm.super.turnAlarmOn();
}
```

## Java Static interface methods

Java 8 also allows us to define and implement static methods in interfaces. Since static methods don't belong to a
particular object, they're not part of the API of the classes implementing the interface; therefore, they have to be
called by using the interface name preceding the method name.

Defining a static method within an interface is identical to defining one in a class. The idea behind static interface
methods is to provide a simple mechanism that allows us to increase the degree of cohesion of a design by putting
together related methods in one single place without having to create an object.

The same can pretty much be done with abstract classes. The main difference is that abstract classes can have
constructors, state, and behavior.

## Test Driven Development(TDD)

**Test Driven Development (TDD)** is software development approach in which test cases are developed to specify and
validate what the code will do. In simple terms, test cases for each functionality are created and tested first and if
the test fails then the new code is written in order to pass the test and making code simple and bug-free.

![alt text](./img/five-steps-of-TDD.png "Five Steps of Test-Driven Development")

Test-Driven Development starts with designing and developing tests for every small functionality of an application. TDD
framework instructs developers to write new code only if an automated test has failed. This avoids duplication of code.

![alt text](./img/TDD.png "Test Driven Development")

## @Qualifier

### Autowire Need for Disambiguation

The `@Autowired` annotation is a great way of making the need to inject a dependency in Spring explicit. Although it's
useful, there are use cases for which this annotation alone isn't enough for Spring to understand which bean to inject.

By default, Spring resolves autowired entries by type.

If more than one bean of the same type is available in the container, the framework will
throw `NoUniqueBeanDefinitionException`, indicating that more than one bean is available for autowiring.

Let's imagine a situation in which two possible candidates exist for Spring to inject as bean collaborators in a given
instance:

```Java

@Component("fooFormatter")
public class FooFormatter implements Formatter {
  public String format() {
    return "foo";
  }
}

@Component("barFormatter")
public class BarFormatter implements Formatter {
  public String format() {
    return "bar";
  }
}

@Component
public class FooService {
  @Autowired
  private Formatter formatter;
}
```

If we try to load FooService into our context, the Spring framework will throw a `NoUniqueBeanDefinitionException`. This
is because Spring doesn't know which bean to inject. To avoid this problem, there are several solutions;
the `@Qualifier` annotation is one of them.

#### @Autowired vs @Inject

The `@Autowired` annotation is used for auto-wiring in the Spring framework. The `@Inject` annotation also serves the
same purpose, but the main difference between them is that `@Inject` is a standard annotation for dependency injection
and `@Autowired` is spring specific.

### @Qualifier annotation

Let's revisit our previous example to see how we solve the problem by including the @Qualifier annotation to indicate
which bean we want to use:

```Java
public class FooService {
  @Autowired
  @Qualifier("fooFormatter")
  private Formatter formatter;
}
```

By including the @Qualifier annotation, together with the name of the specific implementation we want to use, in this
example Foo, we can avoid ambiguity when Spring finds multiple beans of the same type.

We need to take into consideration that the qualifier name to be used is the one declared in the @Component annotation.

Note that we could have also used the @Qualifier annotation on the Formatter implementing classes, instead of specifying
the names in their @Component annotations, to obtain the same effect:

```Java
@Component
@Qualifier("fooFormatter")
public class FooFormatter implements Formatter {
//...
}

@Component
@Qualifier("barFormatter")
public class BarFormatter implements Formatter {
//...
}
```

### @Qualifier vs @Primary

There's another annotation called `@Primary` that we can use to decide which bean to inject when ambiguity is present
regarding dependency injection.

This annotation defines a preference when multiple beans of the same type are present. The bean associated with
the `@Primary` annotation will be used unless otherwise indicated.

Let's see an example:

```Java

@Configuration
public class Config {

  @Bean
  public Employee johnEmployee() {
    return new Employee("John");
  }

  @Bean
  @Primary
  public Employee tonyEmployee() {
    return new Employee("Tony");
  }
}
```

In this example, both methods return the same Employee type. The bean that Spring will inject is the one returned by the
method tonyEmployee. This is because it contains the `@Primary` annotation. This annotation is useful when we want to
specify which bean of a certain type should be injected by default.

If we require the other bean at some injection point, we would need to specifically indicate it. We can do that via
the `@Qualifier` annotation. For instance, we could specify that we want to use the bean returned by the johnEmployee
method by using the @Qualifier annotation.

It's worth noting that if both the `@Qualifier` and `@Primary` annotations are present, then the `@Qualifier` annotation
will have precedence. Basically, `@Primary` defines a default, while `@Qualifier` is very specific.

Let's look at another way of using the @Primary annotation, this time using the initial example:

```Java
@Component
@Primary
public class FooFormatter implements Formatter {
//...
}

@Component
public class BarFormatter implements Formatter {
//...
}
```

In this case, the `@Primary` annotation is placed in one of the implementing classes, and will disambiguate the
scenario.

### @Qualifier vs Autowiring by Name

Another way to decide between multiple beans when autowiring, is by using the name of the field to inject. This is the
default in case there are no other hints for Spring. Let's see some code based on our initial example:

```Java
public class FooService {
  @Autowired
  private Formatter fooFormatter;
}
```

In this case, Spring will determine that the bean to inject is the FooFormatter one, since the field name is matched to
the value that we used in the `@Component` annotation for that bean.

## How to write testable code

> When we write our tests around behaviors rather than the way we implement those behaviors, we are free to change the implementations later, and if the behavior doesn't change, then our tests shouldn't need to change either.

- SOLID design principles
- Law of Demeter
- Use TDD
- Become future proof
- Allow newcomers to write the code as quickly as they join
- Write cleaner functions
- Make third-party calls in seperate modules
- Use Factories/Faker for object initialization
- Stop circular dependencies
- Minimize global declarations
- Replace conditional statements with polymorphism

## Checked Exceptions vs Unchecked Exceptions

Checked exceptions are forced by the compiler and used to indicate exceptional conditions that are out of the control of
the program

Unchecked exceptions are occurred during runtime and are used to indicate programming errors.




























